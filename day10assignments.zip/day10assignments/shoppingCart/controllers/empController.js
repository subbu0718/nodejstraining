function getAll(request,response,next)
{

    // connect to mongodb and do a find request

}

function getEmployee(request,response,next)
{

}

function addEmployee(request,response,next)
{

}

function updateEmployee(request,response,next)
{

}

function deleteEmployee(request,response,next)
{

}
module.exports={getAll,deleteEmployee,updateEmployee,getEmployee,addEmployee}