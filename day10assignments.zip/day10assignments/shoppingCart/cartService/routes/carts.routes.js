var express=require("express");
const router=express.Router();


var cartController=require("../controllers/cartController")

router.get("/",async (req,response)=>{
    var data=await cartController.getAllCartItems();
    // get all the corresponding products form shopping cart service and check for avialability
    if(!data.err)
    {
        response.send(data);      
    }
    else
    {
        response.status(500).send({err: "Error at server side"});
    }
})
router.post("/",(req,res)=>{
    var cartItemToBeAdded=req.body;
    var result=cartController.addItemsToCart(cartItemToBeAdded);
    if(result)
    {
        res.send({msg:"Item added successfully"})
    }
    else
    {
        res.status(202).send({msg:"Not able to add"});
    }
})

// post request to /cart/confirm
router.post("/confirm",async (req,res)=>{
    // take him to paymets page
    // update the products quantities
    var finalisedItems= req.body;
    console.log("finalisedItems = ",finalisedItems);
    await cartController.updateItems(finalisedItems);
    res.send({msg:"Data updated successfully"})
    /* .then((data)=>{
        res.send({msg:"Data updated successfully"})
    })
    .catch(err=>{
        response.status(500).send({err: "Error at server side"});
    }) */

})

router.delete("/",(req,res)=>{
    var cartItemToBeDeleted=req.body;
    var result=cartController.removeItemsFromCart(cartItemToBeDeleted);
    if(result)
    {
        res.send({msg:"Item removed successfully"})
    }
    else
    {
        res.status(202).send({msg:"Not able to remove"});
    }
})

router.put("/:pId",(req,res)=>{
    var cartId=req.params.pId;
    var cartItemToBeUpdated=req.body;
    var result=cartController.updateItemsInCart(cartId, cartItemToBeUpdated);
    if(result)
    {
        res.send({msg:"Item updated successfully"})
    }
    else
    {
        res.status(202).send({msg:"Not able to update"});
    }
})

module.exports=router;