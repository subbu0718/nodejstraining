var express=require("express");
const morgan=require("morgan");//module to be installed
const path=require("path");
// logging of the requests -- morgan
const fs=require("fs");

const {validateToken}=require("../utils");


var productsController=require("../controllers/productsController");

var router=express.Router();
//router.use(validateToken);

// middleware specific to products route
router.use((request,response,next)=>{
    console.log("Products routes middleware",request.rootDirName);// path to he root folder
    var wStream=fs.createWriteStream(path.join(request.rootDirName,"log","serverLog.txt"),{flags:"a"});
    morgan("short",{stream:wStream})
    wStream.close();
    next();
})

//get request to /products
router.get("/",(request,response,next)=>{
   var data=productsController.getAllProducts();
   response.send(data);
})

router.get("/:pId",(request,response,next)=>{
    var data=productsController.getProduct(request.params.pId);
    response.send(data);
 })
 

router.put("/:pId",(request,response,next)=>{
    var productIdToBeUpdated=request.params.pId;
    var updatedData=request.body;
    var result=productsController.updateProduct(productIdToBeUpdated,updatedData);
    if(result)
    {
        response.send({msg:`Product Id ${productIdToBeUpdated} updated successfully`})
    }
    else
    {
        response.status(202).send({msg:`Product Id : ${productIdToBeUpdated} not found`})
    }
})

router.post("/",(request,response,next)=>{
    
})

router.delete("/:pId",(request,response,next)=>{
    var productIdToBeDeleted=request.params.pId;
    console.log("Product id to be deleted",productIdToBeDeleted)
    var result=productsController.deleteProduct(productIdToBeDeleted);
    if(result)
    {
        response.send({msg:`Product Id ${productIdToBeDeleted} deleted successfully`})
    }
    else
    {
        response.status(202).send({msg:`Product Id : ${productIdToBeDeleted} not found`})
    }
})

module.exports=router;


/*
Different types of data sent as response
string
json
buffer
files
    images
    text
    pdf
    html
status code with no content
redirect
template 
    static content
    dynamic content

Template -- views
Specify the view engines
    jade
    ejs
    handlebars

*/
