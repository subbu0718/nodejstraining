var express=require("express");
const path=require("path");
// logging of the requests -- morgan


var empController=require("../controllers/empController");

var router=express.Router();

// /employees
router.get("/",empController.getAll)
router.get("/:empId")
router.post("/")
router.put("/")
router.delete("/")

module.exports=router;