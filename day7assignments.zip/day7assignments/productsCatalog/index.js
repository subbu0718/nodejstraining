const express = require("express");
const qs = require("querystring");
const bodyParser = require('body-parser');
const port=3000;


var prodArr = [
    {"productId": 1001, "productName":"Monitor", price:20000, quantity:10, category:"computer"},
    {"productId": 1002, "productName":"Keyboard", price:2000, quantity:5, category:"computer"},
    {"productId": 1003, "productName":"Mouse", price:500, quantity:20, category:"computer"},
    {"productId": 1004, "productName":"CPU", price:15000, quantity:5, category:"computer"},
    {"productId": 1005, "productName":"Speakers", price:3000, quantity:25, category:"computer"},
    {"productId": 1006, "productName":"Charger", price:1000, quantity:30, category:"mobile"},
    {"productId": 1007, "productName":"Headset", price:2000, quantity:10, category:"mobile"}
];
var app=express();

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

app.get("/products", (request, response)=>{
    response.send(prodArr);
});

app.post("/products/addNewProducts", (request,response)=>{
    var newArr = request.body;
    var len = prodArr.length;
    if (newArr[0] != null){
        prodArr[len] = newArr[0];
        response.send(JSON.stringify(prodArr));    
    } else {
        response.statusCode=401;
        response.send(JSON.stringify({err:"Products not added to the catalog"}));
    }
});

app.patch("/products/updateProduct", (request, response)=>{
    var productTobeUpdatedObj=request.body;
    console.log(productTobeUpdatedObj);
    var pos=prodArr.findIndex(item => item.productId == productTobeUpdatedObj[0].productId);
    console.log(pos);
    if(pos >= 0)
    {
        prodArr[pos] = productTobeUpdatedObj;
        response.send(JSON.stringify({msg:"Data updated successfully",updatedData:prodArr}));
    }
    else
    {
        response.statusCode=401;
        response.send(JSON.stringify({err:"Data does not exists to update"}));
    }
});

app.delete("/products/deleteProduct", (request, response)=>{
    var productTobeDeletedObj=request.body;
    console.log(productTobeDeletedObj);
    var pos=prodArr.findIndex(item => item.productId == productTobeDeletedObj[0].productId);
    console.log(pos);
    if(pos >= 0)
    {
        var deletedObj = prodArr.splice(pos,1);
        response.send(JSON.stringify({msg:"Data updated successfully",updatedData:prodArr}));
    }
    else
    {
        response.statusCode=401;
        response.send(JSON.stringify({err:"Data does not exists to delete"}));
    }
});

app.listen(port, ()=>{
    console.log(`Server started at this port number ${port}`);
});