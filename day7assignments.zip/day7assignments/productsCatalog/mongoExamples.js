const fs = require("fs");
const { MongoClient } = require("mongodb");

const uri = "mongodb://127.0.0.1:27017/";

const mongoClient = new MongoClient(uri,{ useUnifiedTopology: true } );
mongoClient.connect()
    .then((client) => {
        // switch over to the db : dxcDb
        var dbName = client.db("dxcDb");
        // select the collection
        var collName = dbName.collection("emp");

        const insertDocs = [{ "empId": 201, "empName": "sara", salary: 10000, "deptId": "D4" },
                            { "empId": 202, "empName": "tara", salary: 20000, "deptId": "D4" }];
        collName.insertMany(insertDocs)
            .then((res) => {
                console.log("Response of insertMany", res);
                console.log("Response of insertMany: Inserted Id:", res.insertedIds);
                console.log("Response of insertOne: Inserted Count:", res.insertedCount);
            })
            .catch((err) => {
                console.log("Error doing the insertOne operation", err);
                
            })


    })
    .catch((err) => {
        console.log("Error connecting to mongodb", err)
    })

