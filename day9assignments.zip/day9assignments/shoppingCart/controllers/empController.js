const { MongoClient } = require("mongodb");
const uri = "mongodb://127.0.0.1:27017/";
const mongoClient = new MongoClient(uri,{ useUnifiedTopology: true } );
var employees=require("../model/Employees");

async function getAll()
{
    var client = await mongoClient.connect()
    var dbName = client.db("dxcDb");
    var collName = dbName.collection("emp");
    const cursor=collName.find();
    var empArr=[];
    await cursor.forEach(element => {
        empArr.push(element);
    });
    return empArr;
}

async function getEmployee(employeeId)
{
    console.log("hello");
    try {
        var client = await mongoClient.connect()
        var dbName = client.db("dxcDb");
        var collName = dbName.collection("emp");
        console.log("employeeId in get emp controller" + employeeId);
        employeeId = parseInt(employeeId);
        var searchObj = {empId:employeeId};
        const element = await collName.findOne(searchObj);
        console.log("element = ", element);
        return element;
    } catch {
        console.log("Error");
        mongoClient.close();
    } finally {
        // mongoClient.close();
    }
}

function addEmployee(request,response,next)
{

}

function updateEmployee(request,response,next)
{

}

function deleteEmployee(request,response,next)
{

}
module.exports={getAll,deleteEmployee,updateEmployee,getEmployee,addEmployee}
