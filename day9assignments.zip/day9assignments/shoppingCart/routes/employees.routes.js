var express=require("express");
const path=require("path");
const fs=require("fs");
const morgan=require("morgan");
const {validateToken}=require("../utils");

var empController=require("../controllers/empController");
var router=express.Router();

router.use(validateToken);

// middleware specific to products route
router.use((request,response,next)=>{
    console.log("Products routes middleware",request.rootDirName);// path to he root folder
    var wStream=fs.createWriteStream(path.join(request.rootDirName,"log","serverLog.txt"),{flags:"a"});
    morgan("short",{stream:wStream})
    wStream.close();
    next();
})

// /employees
router.get("/", (request, response, next)=>{
    var data = empController.getAll();
    var empArr = [];
    console.log("data = " , data);
    data.then((res) => {
        response.send(res);
    }).catch((err) => {
        console.log("Error doing the find operation", err);
        
    })
});

router.get("/:empId", (request, response, next)=>{
    var empId=request.params.empId;
    console.log("empId = " , empId);
    var result=empController.getEmployee(empId);
    result.then((res) => {
        response.send(res);
    }).catch((err) => {
        console.log("Error doing the find operation", err);
        
    })
});

router.post("/")
router.put("/")
router.delete("/")

module.exports=router;